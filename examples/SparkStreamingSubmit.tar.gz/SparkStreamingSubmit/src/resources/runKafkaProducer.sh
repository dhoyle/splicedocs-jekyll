#!/usr/bin/env bash

###############################################################################
#  this is an example script the will require edits to make it work in any
#  environment.
###############################################################################
HOST="srv051"
KAFKA_LIB_DIR="/opt/cloudera/parcels/KAFKA/lib/kafka/libs/*"
java -cp ../../target/splice-adapter-kafka-streaming-1.0-SNAPSHOT.jar:${KAFKA_LIB_DIR}\
    com.splicemachine.sample.KafkaTopicProducer \
    ${HOST}:9092 $@
