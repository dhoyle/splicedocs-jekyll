#!/bin/bash

for ((cnt = 0; cnt < 2000; cnt++))
do
  echo $cnt
  sh ./runKafkaProducer.sh weather 500
  sleep 2
done

